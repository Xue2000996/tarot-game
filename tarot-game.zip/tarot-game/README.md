# tarot-game
A sequential Tarot LLM game for NTU AI Lab2.2

# Tarot Game – Multi-layer Interactive Tarot Reading (進階版)

本專案是一個 **多層互動式塔羅占卜遊戲**，透過 OpenAI API 實作三層互動、追問、抽牌、解牌與最終回顧。  
整體流程符合課程要求：意圖解析、卡牌解讀、逐回合追問與最終總結。

---

## 🔧 安裝環境

需要 Python 3.10+。

### 1. Clone 專案（或下載 zip）
```bash
git clone https://github.com/Xue2000996/tarot-game.git
cd tarot-game
```

### 2. 建立虛擬環境
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. 安裝套件
```bash
pip install -r requirements.txt
```

---

## 🔑 設定 API Key
```bash
export OPENAI_API_KEY="你的key"
```

---

## ▶️ 執行遊戲

```bash
python3 main.py
```

---

## 🃏 遊戲流程

1. 玩家選擇主題（Love / Study / Career / Other）
2. 玩家輸入主要困擾
3. 系統會：
   - 抽三張牌（Past / Present / Future）
   - 每一層包含 LLM 解讀、追問、玩家回覆
4. 三層互動後，系統會產生完整 Final Review
5. 結果儲存於 `runs/` 資料夾

---

## 📁 專案結構

```
tarot-game/
│── main.py
│── cards.json
│── prompts/
│── runs/
│── README.md
└── report.md
```

---

## 📝 注意事項

- 若 API 顯示 quota 不足，請更換 key。
- 模型使用 `gpt-3.5-turbo`（符合你的權限）。

