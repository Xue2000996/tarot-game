import json, random, os, datetime
from pathlib import Path

# ====== API KEY ======
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
if not OPENAI_API_KEY:
    raise ValueError("找不到 OPENAI_API_KEY。請先 export 再跑。")

from openai import OpenAI
client = OpenAI(api_key=OPENAI_API_KEY)

MODEL = "gpt-3.5-turbo"  # 可用模型

# ====== paths ======
BASE_DIR = Path(__file__).parent
PROMPT_DIR = BASE_DIR / "prompts"
RUNS_DIR = BASE_DIR / "runs"
CARDS_PATH = BASE_DIR / "cards.json"
RUNS_DIR.mkdir(exist_ok=True)

def load_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")

def call_llm(prompt: str, variables: dict, json_mode: bool):
    """通用 LLM 呼叫"""
    filled = prompt.format(**variables)
    response = client.chat.completions.create(
        model=MODEL,
        temperature=0.7,
        messages=[
            {"role": "system", "content": "你是嚴謹又友善的塔羅遊戲 LLM 模組。"},
            {"role": "user", "content": filled}
        ],
        response_format={"type": "json_object"} if json_mode else None
    )
    content = response.choices[0].message.content
    return json.loads(content) if json_mode else content

def draw_card(cards: list):
    card = random.choice(cards)
    orientation = random.choice(["upright", "reversed"])
    keywords = card["upright_keywords"] if orientation == "upright" else card["reversed_keywords"]
    return card["name"], orientation, keywords

# ====== 主題選單 ======
TOPIC_MAP = {
    "1": "love",
    "2": "study",
    "3": "career",
    "4": "other"
}

# ====== 追問 prompt（內嵌）======
FOLLOWUP_PROMPT = """
你是塔羅占卜遊戲的追問者（像諮商師＋占卜師的混合）。

玩家主題：{topic}
玩家最初問題：{question}

目前為止的對話與占卜歷程（JSON）：
{history_json}

剛解讀的新牌結果（JSON）：
{last_interpretation_json}

任務：
1) 讀玩家最初問題 + 歷程 + 本次解讀，找出「最值得往下挖的一個點」。
2) 對玩家提出 1~2 個追問，讓玩家更具體講出原因/情緒/阻礙。
3) 追問要貼合玩家情境，不要問泛用問題。

請輸出 JSON：
- followup_questions: 字串陣列（1~2 個）
- why_this_matters: 1 句說明

規則：
- 只能輸出 JSON
"""

def main():
    # ====== 讀卡牌 ======
    cards = json.loads(CARDS_PATH.read_text(encoding="utf-8"))

    # ====== 讀 prompt ======
    intent_prompt = load_text(PROMPT_DIR / "intent_parser.txt")
    first_prompt  = load_text(PROMPT_DIR / "interpret_first.txt")
    next_prompt   = load_text(PROMPT_DIR / "interpret_next.txt")
    review_prompt = load_text(PROMPT_DIR / "final_review.txt")

    print("=== 多層互動塔羅占卜遊戲（進階版） ===")
    print("\n請選擇主題：")
    print("  1) Love")
    print("  2) Study")
    print("  3) Career")
    print("  4) Other")

    topic_choice = input("\n請輸入 1~4： ").strip()
    while topic_choice not in TOPIC_MAP:
        topic_choice = input("請輸入 1~4： ").strip()

    topic_input = TOPIC_MAP[topic_choice]

    if topic_input == "other":
        topic_input = input("請輸入你想問的主題： ").strip()

    player_text = input("\n請描述你的困擾 / 問題： ").strip()

    # ====== Task0：意圖解析 ======
    intent = call_llm(
        intent_prompt,
        {"player_text": f"[topic_hint={topic_input}] {player_text}"},
        json_mode=True
    )

    state = {
        "topic": intent.get("topic", topic_input),
        "question": intent["question"],
        "emotion": intent.get("emotion", "other"),
        "constraints": intent.get("constraints", []),
        "rounds": []
    }

    # 正統塔羅：Past / Present / Future
    positions = [
        ("past", "Past（過去）"),
        ("present", "Present（現在）"),
        ("future", "Future（未來）")
    ]

    prev_followup_answer = None

    # ====== 三層互動 ======
    for step, (pos_key, pos_label) in enumerate(positions, start=1):
        print(f"\n====================")
        print(f" 第 {step} 層互動開始 → {pos_label}")
        print(f"====================")

        # 第一層用第一段敘述；第二層開始用上一層玩家回答
        if step == 1:
            layer_input = player_text
        else:
            layer_input = prev_followup_answer  # 自動帶入，不再重複輸入

        # ====== 抽牌 ======
        card_name, orientation, keywords = draw_card(cards)

        # ====== 解讀牌 ======
        if step == 1:
            interp = call_llm(
                first_prompt,
                {
                    "topic": state["topic"],
                    "question": state["question"],
                    "emotion": state["emotion"],
                    "constraints": state["constraints"],
                    "layer_input": layer_input,
                    "position": pos_key,
                    "position_label": pos_label,
                    "card_name": card_name,
                    "orientation": orientation,
                    "keywords": keywords
                },
                json_mode=True
            )
        else:
            history_json = json.dumps(state["rounds"], ensure_ascii=False, indent=2)
            last_interp_json = json.dumps(state["rounds"][-1]["interpretation"], ensure_ascii=False, indent=2)

            interp = call_llm(
                next_prompt,
                {
                    "step": step,
                    "topic": state["topic"],
                    "question": state["question"],
                    "emotion": state["emotion"],
                    "constraints": state["constraints"],
                    "history_json": history_json,
                    "player_followup_answer": prev_followup_answer,
                    "last_interpretation_json": last_interp_json,
                    "layer_input": layer_input,
                    "position": pos_key,
                    "position_label": pos_label,
                    "card_name": card_name,
                    "orientation": orientation,
                    "keywords": keywords
                },
                json_mode=True
            )

        # ====== 顯示本層 ======
        print(f"\n--- 第 {step} 層抽牌 ({pos_label}) ---")
        print("抽到：", card_name, f"({orientation})")
        print("關鍵字：", "、".join(keywords))
        print("解讀：")
        print(json.dumps(interp, ensure_ascii=False, indent=2))

        # ====== 追問 ======
        history_json = json.dumps(state["rounds"], ensure_ascii=False, indent=2)
        last_interp_json = json.dumps(interp, ensure_ascii=False, indent=2)

        followup = call_llm(
            FOLLOWUP_PROMPT,
            {
                "topic": state["topic"],
                "question": state["question"],
                "history_json": history_json,
                "last_interpretation_json": last_interp_json
            },
            json_mode=True
        )

        print("\n我想再追問你一些問題：")
        for i, q in enumerate(followup["followup_questions"], start=1):
            print(f"{i}. {q}")

        # 玩家回答（只輸入一次）
        player_followup_answer = input("\n你的回覆： ").strip()
        prev_followup_answer = player_followup_answer

        # ====== 存 round ======
        state["rounds"].append({
            "layer": step,
            "position": pos_key,
            "player_input": layer_input,
            "card": card_name,
            "orientation": orientation,
            "keywords": keywords,
            "interpretation": interp,
            "followup_questions": followup,
            "player_followup_answer": player_followup_answer
        })

    # ====== Final Review ======
    history_json = json.dumps(state["rounds"], ensure_ascii=False, indent=2)
    review_md = call_llm(
        review_prompt,
        {
            "topic": state["topic"],
            "question": state["question"],
            "history_json": history_json
        },
        json_mode=False
    )

    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    run_json_path = RUNS_DIR / f"run_{ts}.json"
    run_md_path = RUNS_DIR / f"run_{ts}.md"
    run_json_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    run_md_path.write_text(review_md, encoding="utf-8")

    print("\n=== 本次多層占卜回顧 Review ===\n")
    print(review_md)
    print(f"\n(已存檔：{run_json_path.name}, {run_md_path.name})")

if __name__ == "__main__":
    main()
